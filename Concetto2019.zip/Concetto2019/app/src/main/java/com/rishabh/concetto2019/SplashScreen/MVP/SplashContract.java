package com.rishabh.concetto2019.SplashScreen.MVP;

public class SplashContract
{
    public interface view{

    }

    public interface presenter {


    }
}
