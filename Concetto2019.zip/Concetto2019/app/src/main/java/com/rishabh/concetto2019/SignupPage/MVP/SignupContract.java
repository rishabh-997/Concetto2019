package com.rishabh.concetto2019.SignupPage.MVP;

public class SignupContract
{
    interface  view{

    }

    interface presenter{

    }
}
