package com.rishabh.concetto2019.HomePage.MVP;

public class HomePageContract
{
    interface  view{


    }

    interface presenter{

    }
}
