package com.rishabh.concetto2019.LoginPage.MVP;

public class LoginContract
{
    interface  view{

    }

    interface presenter{

    }
}
