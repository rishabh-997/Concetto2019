package com.rishabh.concetto2019.EventPage.MVP;

public class EventContract
{
    interface  view{

    }

    interface presenter{

    }
}
