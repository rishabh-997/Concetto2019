package com.rishabh.concetto2019.WorkshopPage.MVP;

public class WorkshopContract
{
    interface  view{

    }

    interface presenter{

    }
}
