package com.rishabh.concetto2019.TechTalkPage.MVP;

public class TechTalkContract
{
    interface  view{

    }

    interface presenter{

    }
}
