package com.rishabh.concetto2019.EventDetailPage.MVP;

public class EventDetailContract
{
    interface  view{

    }

    interface presenter{

    }
}
