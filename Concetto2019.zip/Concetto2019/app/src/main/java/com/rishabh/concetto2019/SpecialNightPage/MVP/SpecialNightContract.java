package com.rishabh.concetto2019.SpecialNightPage.MVP;

public class SpecialNightContract
{
    interface  view{

    }

    interface presenter{

    }
}
